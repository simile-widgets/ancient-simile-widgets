/** 
 * Just a test.
 * @throws {ExceptionType} This is the label text.
 */
function processFile(fileId) {

}

/** 
 * @exception {OutOfMemory}
 */
function readFile(path) {

}

/** 
 * @throws {IOException}
 * @throws {PermissionDenied}
 */
function writeFile(path) {

}